// SPDX-License-Identifier: (Apache-2.0 OR MIT)

pub const INVALID_STR: &str = "str is not valid UTF-8: surrogates not allowed";
